# Clock apps (Android)

Analog clock face with app shortcuts, modeled after our chat widget:

- 16 app shortcuts in two rings around the dial
  - tap an app to launch it
  - long-press an app to remove it
  - tap the dashed "+" slot to add any installed app (icons load automatically)
- Center complications: small digital clock (tap it to open a timer)
  and weather (tap it to set your city; live data from Open-Meteo, no API key)
- Droplet button below the dial: clock background (Default / Paper / Dark / Night)
- Everything is saved on the phone (apps, face, city, weather cache)

## Build the APK

1. Install Android Studio: https://developer.android.com/studio
2. File > Open > select this folder (AnalogClockApps)
3. Wait for Gradle sync (it downloads the SDK / build tools automatically;
   accept any license prompts)
4. Connect a phone with USB debugging enabled, or start an emulator
5. Run > Run 'app'  — or  Build > Build Bundle(s)/APK(s) > Build APK(s)
   to produce app-debug.apk in app/build/outputs/apk/debug/

## Notes

- Requires Android 8.0 (API 26) or newer.
- Internet permission is used only for the weather request.
- If your phone blocks installing the debug APK, allow "install from unknown
  sources" for your file manager/browser in Settings.
