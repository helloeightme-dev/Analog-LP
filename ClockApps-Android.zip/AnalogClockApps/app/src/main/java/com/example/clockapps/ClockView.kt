package com.example.clockapps

import android.app.AlarmClock
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

class ClockView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val prefs: SharedPreferences = context.getSharedPreferences("clock", Context.MODE_PRIVATE)
    private val pm = context.packageManager
    private val handler = Handler(Looper.getMainLooper())
    private val MAX = 16

    private var appPkgs: MutableList<String> = loadApps()
    private val iconCache = HashMap<String, Drawable?>()

    private var faceIndex: Int = prefs.getInt("face", 0)
    private var city: String? = prefs.getString("city", null)
    private var weatherText: String = prefs.getString("wx", "Set city") ?: "Set city"
    private var lastFetch: Long = prefs.getLong("wxTime", 0L)

    private val faceColors = intArrayOf(0xFFF2F2F2.toInt(), Color.WHITE, 0xFF2B2B2B.toInt(), 0xFF0B0B0B.toInt())
    private val faceNames = arrayOf("Default", "Paper", "Dark", "Night")
    private val isDark: Boolean get() = faceIndex >= 2

    private var cx = 0f
    private var cy = 0f
    private var R = 0f
    private var slotR = 0f
    private var slotCenters = Array<Pair<Float, Float>?>(MAX) { null }
    private var pendant = Pair(0f, 0f)
    private var pendantR = 0f
    private var compTimeY = 0f
    private var compWxY = 0f

    private val fmt = SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tickMajorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tickMinorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val handPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val secPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFD93025.toInt() }
    private val slotBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slotBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clipPath = Path()
    private val dropPath = Path()
    private val plusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(3), dp(3)), 0f)
    }

    init {
        val cached = prefs.getString("wx", null)
        if (cached != null) weatherText = cached
        city?.let {
            if (System.currentTimeMillis() - lastFetch > 30 * 60 * 1000L) fetchWeather(it)
        }
    }

    private fun dp(v: Int): Float = v * resources.displayMetrics.density
    private fun sp(v: Int): Float = v * resources.displayMetrics.scaledDensity
    private fun primaryColor(): Int = if (isDark) Color.WHITE else 0xFF1A1A1A.toInt()
    private fun secondaryColor(): Int = if (isDark) 0xFF9A9A9A.toInt() else 0xFF7A7A7A.toInt()
    private fun borderColor(): Int = if (isDark) 0xFF3D3D3D.toInt() else 0xFFDCDCDC.toInt()
    private fun slotBgColor(): Int = if (isDark) 0xFF333333.toInt() else Color.WHITE

    private fun loadApps(): MutableList<String> {
        val raw = prefs.getString("apps", "") ?: ""
        return raw.split(";").filter { it.isNotBlank() }.toMutableList()
    }

    private fun saveApps() {
        prefs.edit().putString("apps", appPkgs.joinToString(";")).apply()
    }

    private fun labelFor(pkg: String): String = try {
        pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
    } catch (e: Exception) {
        "?"
    }

    private fun iconFor(pkg: String): Drawable? = iconCache.getOrPut(pkg) {
        try {
            pm.getApplicationInfo(pkg, 0).loadIcon(pm)
        } catch (e: Exception) {
            null
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cx = w / 2f
        R = min(w, h) / 2f - dp(40)
        cy = h / 2f - dp(8)
        compTimeY = cy - 0.11f * R
        compWxY = cy + 0.16f * R

        // face
        facePaint.color = faceColors[faceIndex]
        borderPaint.color = borderColor()
        borderPaint.strokeWidth = dp(1)
        canvas.drawCircle(cx, cy, R, facePaint)
        canvas.drawCircle(cx, cy, R, borderPaint)

        // ticks
        tickMajorPaint.color = primaryColor()
        tickMajorPaint.strokeWidth = dp(2)
        tickMinorPaint.color = secondaryColor()
        tickMinorPaint.strokeWidth = dp(1)
        for (i in 0 until 60) {
            val a = Math.toRadians((i * 6).toDouble())
            val major = i % 5 == 0
            val r1 = if (major) 0.86f else 0.92f
            val paint = if (major) tickMajorPaint else tickMinorPaint
            canvas.drawLine(
                cx + (r1 * R * sin(a)).toFloat(), cy - (r1 * R * cos(a)).toFloat(),
                cx + (0.955f * R * sin(a)).toFloat(), cy - (0.955f * R * cos(a)).toFloat(),
                paint
            )
        }

        // center complications: digital time + weather
        textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        textPaint.textSize = sp(13)
        textPaint.color = primaryColor()
        canvas.drawText(fmt.format(Date()), cx, compTimeY + sp(4), textPaint)
        textPaint.typeface = android.graphics.Typeface.DEFAULT
        textPaint.textSize = sp(10)
        textPaint.color = secondaryColor()
        canvas.drawText(weatherText, cx, compWxY + sp(4), textPaint)

        // hands
        val cal = java.util.Calendar.getInstance()
        val seconds = cal.get(java.util.Calendar.SECOND) + cal.get(java.util.Calendar.MILLISECOND) / 1000f
        val minutes = cal.get(java.util.Calendar.MINUTE) + seconds / 60f
        val hours = cal.get(java.util.Calendar.HOUR_OF_DAY) % 12 + minutes / 60f
        handPaint.color = primaryColor()
        drawHand(canvas, hours * 30f, 0.28f * R, dp(5))
        drawHand(canvas, minutes * 6f, 0.42f * R, dp(3))
        drawHand(canvas, seconds * 6f, 0.50f * R, dp(2), 0.08f * R, secPaint)

        // pin
        pinPaint.color = primaryColor()
        canvas.drawCircle(cx, cy, dp(4), pinPaint)
        pinPaint.color = 0xFFD93025.toInt()
        canvas.drawCircle(cx, cy, dp(1.6f).toFloat(), pinPaint)

        // app slots (drawn above the hands)
        slotR = 0.115f * R
        for (i in 0 until MAX) {
            val ringR = if (i < 8) 0.68f * R else 0.44f * R
            val idx = if (i < 8) i else i - 8
            val ang = Math.toRadians((-90 + idx * 45).toDouble())
            val x = cx + (ringR * cos(ang)).toFloat()
            val y = cy + (ringR * sin(ang)).toFloat()
            slotCenters[i] = Pair(x, y)
            val cr = if (i < 8) slotR else slotR * 0.9f
            when {
                i < appPkgs.size -> drawAppSlot(canvas, x, y, cr, appPkgs[i])
                i == appPkgs.size -> drawPlus(canvas, x, y, cr)
            }
        }

        // background pendant button
        pendantR = dp(14)
        pendant = Pair(cx, cy + R + dp(14))
        drawPendant(canvas)

        postInvalidateOnAnimation()
    }

    private fun drawHand(canvas: Canvas, angleDeg: Float, len: Float, width: Float, tail: Float = 0f, paint: Paint = handPaint) {
        val a = Math.toRadians((angleDeg - 90).toDouble())
        val dx = cos(a).toFloat()
        val dy = sin(a).toFloat()
        paint.strokeWidth = width
        canvas.drawLine(cx - tail * dx, cy - tail * dy, cx + len * dx, cy + len * dy, paint)
    }

    private fun drawAppSlot(canvas: Canvas, x: Float, y: Float, r: Float, pkg: String) {
        slotBgPaint.color = slotBgColor()
        slotBorderPaint.color = borderColor()
        slotBorderPaint.strokeWidth = dp(1)
        canvas.drawCircle(x, y, r, slotBgPaint)
        canvas.drawCircle(x, y, r, slotBorderPaint)
        val icon = iconFor(pkg)
        if (icon != null) {
            clipPath.reset()
            clipPath.addCircle(x, y, r - dp(1), Path.Direction.CCW)
            canvas.save()
            canvas.clipPath(clipPath)
            val b = (r - dp(1)).toInt()
            icon.setBounds((x - b), (y - b), (x + b).toInt(), (y + b).toInt())
            icon.draw(canvas)
            canvas.restore()
        } else {
            textPaint.color = primaryColor()
            textPaint.textSize = r * 0.9f
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            val label = labelFor(pkg)
            canvas.drawText(if (label.isEmpty()) "?" else label.substring(0, 1).uppercase(), x, y + r * 0.32f, textPaint)
        }
    }

    private fun drawPlus(canvas: Canvas, x: Float, y: Float, r: Float) {
        plusPaint.color = secondaryColor()
        plusPaint.strokeWidth = dp(1)
        canvas.drawCircle(x, y, r, plusPaint)
        textPaint.color = secondaryColor()
        textPaint.textSize = r
        textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        canvas.drawText("+", x, y + r * 0.35f, textPaint)
    }

    private fun drawPendant(canvas: Canvas) {
        val x = pendant.first
        val y = pendant.second
        slotBgPaint.color = slotBgColor()
        slotBorderPaint.color = borderColor()
        slotBorderPaint.strokeWidth = dp(1)
        canvas.drawCircle(x, y, pendantR, slotBgPaint)
        canvas.drawCircle(x, y, pendantR, slotBorderPaint)
        val s = pendantR / 8f
        dropPath.reset()
        dropPath.moveTo(x, y - 5 * s)
        dropPath.cubicTo(x + 3.4f * s, y - 1.6f * s, x + 3.6f * s, y + 0.6f * s, x + 2.4f * s, y + 2.4f * s)
        dropPath.cubicTo(x + 1.2f * s, y + 4.2f * s, x - 1.2f * s, y + 4.2f * s, x - 2.4f * s, y + 2.4f * s)
        dropPath.cubicTo(x - 3.6f * s, y + 0.6f * s, x - 3.4f * s, y - 1.6f * s, x, y - 5 * s)
        dropPath.close()
        handPaint.color = primaryColor()
        handPaint.strokeWidth = dp(2)
        handPaint.style = Paint.Style.STROKE
        canvas.drawPath(dropPath, handPaint)
    }

    // ---------- touch ----------

    private var downX = 0f
    private var downY = 0f
    private var longPressIndex = -1

    private val longPressRunnable = Runnable {
        if (longPressIndex in 0 until appPkgs.size) {
            val pkg = appPkgs[longPressIndex]
            appPkgs.removeAt(longPressIndex)
            saveApps()
            Toast.makeText(context, "Removed " + labelFor(pkg), Toast.LENGTH_SHORT).show()
            invalidate()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                longPressIndex = slotAt(event.x, event.y)
                if (longPressIndex in 0 until appPkgs.size) handler.postDelayed(longPressRunnable, 550)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(event.x - downX, event.y - downY) > dp(10)) handler.removeCallbacks(longPressRunnable)
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (hypot(event.x - downX, event.y - downY) <= dp(10)) handleTap(event.x, event.y)
            }
        }
        return true
    }

    private fun slotAt(x: Float, y: Float): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in 0 until MAX) {
            val c = slotCenters[i] ?: continue
            val d = hypot(x - c.first, y - c.second)
            val r = if (i < 8) slotR else slotR * 0.9f
            if (d < r + dp(6) && d < bestD) {
                best = i
                bestD = d
            }
        }
        return best
    }

    private fun handleTap(x: Float, y: Float) {
        if (hypot(x - pendant.first, y - pendant.second) < pendantR + dp(6)) {
            showFacePicker()
            return
        }
        val idx = slotAt(x, y)
        if (idx in 0 until appPkgs.size) {
            launchApp(appPkgs[idx])
            return
        }
        if (idx == appPkgs.size && appPkgs.size < MAX) {
            showAppPicker()
            return
        }
        if (abs(x - cx) < 0.32f * R && abs(y - compTimeY) < 0.06f * R) {
            openTimer()
            return
        }
        if (abs(x - cx) < 0.32f * R && abs(y - compWxY) < 0.06f * R) {
            showCityDialog()
            return
        }
    }

    // ---------- actions ----------

    private fun launchApp(pkg: String) {
        try {
            pm.getLaunchIntentForPackage(pkg)?.let { context.startActivity(it) }
        } catch (e: Exception) {
            Toast.makeText(context, "Can't open app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openTimer() {
        try {
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, 600)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Timer")
            context.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(context, "No clock app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showFacePicker() {
        AlertDialog.Builder(context)
            .setTitle("Clock background")
            .setItems(faceNames) { _, which ->
                faceIndex = which
                prefs.edit().putInt("face", faceIndex).apply()
                invalidate()
            }
            .show()
    }

    private fun showCityDialog() {
        val input = EditText(context)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.setText(city ?: "")
        input.hint = "City, e.g. Kathmandu"
        AlertDialog.Builder(context)
            .setTitle("Weather city")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val c = input.text.toString().trim()
                if (c.isNotEmpty()) {
                    city = c
                    prefs.edit().putString("city", c).apply()
                    fetchWeather(c)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAppPicker() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val grid = GridView(context)
        grid.numColumns = 4
        grid.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380).toInt())
        grid.adapter = AppAdapter(infos)
        val dialog = AlertDialog.Builder(context)
            .setTitle("Add app")
            .setView(grid)
            .setNegativeButton("Cancel", null)
            .show()
        grid.setOnItemClickListener { _, _, pos, _ ->
            val pkg = infos[pos].activityInfo.packageName
            if (!appPkgs.contains(pkg) && appPkgs.size < MAX) {
                appPkgs.add(pkg)
                saveApps()
                invalidate()
            }
            dialog.dismiss()
        }
    }

    inner class AppAdapter(private val infos: List<ResolveInfo>) : BaseAdapter() {
        override fun getCount() = infos.size
        override fun getItem(pos: Int) = infos[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: android.view.View?, parent: ViewGroup?): android.view.View {
            val info = infos[pos]
            val cell = LinearLayout(context)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val pad = dp(8).toInt()
            cell.setPadding(pad, pad, pad, pad)
            val iv = ImageView(context)
            val size = dp(44).toInt()
            iv.layoutParams = LinearLayout.LayoutParams(size, size)
            iv.setImageDrawable(info.loadIcon(pm))
            val tv = TextView(context)
            tv.text = info.loadLabel(pm)
            tv.maxLines = 1
            tv.textSize = 11f
            tv.gravity = Gravity.CENTER
            cell.addView(iv)
            cell.addView(tv)
            return cell
        }
    }

    // ---------- weather (Open-Meteo, no API key) ----------

    private fun fetchWeather(cityName: String) {
        weatherText = "Loading..."
        invalidate()
        thread {
            var result: String
            try {
                val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(cityName, "UTF-8") + "&count=1"
                val geoJson = JSONObject(httpGet(geoUrl))
                val results = geoJson.getJSONArray("results")
                val first = results.getJSONObject(0)
                val lat = first.getDouble("latitude")
                val lon = first.getDouble("longitude")
                val fxUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code"
                val fxJson = JSONObject(httpGet(fxUrl))
                val current = fxJson.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").roundToInt()
                val code = current.getInt("weather_code")
                result = "$temp\u00B0 ${wmoLabel(code)}"
                prefs.edit().putString("wx", result).putLong("wxTime", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
                result = "Weather unavailable"
            }
            weatherText = result
            handler.post { invalidate() }
        }
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.requestMethod = "GET"
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun wmoLabel(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow showers"
        in 95..99 -> "Thunder"
        else -> "Unknown"
    }
}
